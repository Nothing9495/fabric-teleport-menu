package io.wispforest.owo.config.ui;

import ;
import I;
import Z;
import io.wispforest.owo.Owo;
import io.wispforest.owo.config.ConfigWrapper;
import io.wispforest.owo.config.Option;
import io.wispforest.owo.config.Option.Key;
import io.wispforest.owo.config.annotation.ExcludeFromScreen;
import io.wispforest.owo.config.annotation.Expanded;
import io.wispforest.owo.config.annotation.RestartRequired;
import io.wispforest.owo.config.annotation.SectionHeader;
import io.wispforest.owo.config.ui.OptionComponentFactory.Result;
import io.wispforest.owo.config.ui.component.*;
import io.wispforest.owo.ui.base.BaseComponent;
import io.wispforest.owo.ui.base.BaseUIModelScreen;
import io.wispforest.owo.ui.component.ButtonComponent;
import io.wispforest.owo.ui.component.Components;
import io.wispforest.owo.ui.component.LabelComponent;
import io.wispforest.owo.ui.component.TextBoxComponent;
import io.wispforest.owo.ui.container.*;
import io.wispforest.owo.ui.core.*;
import io.wispforest.owo.ui.parsing.UIParsing;
import io.wispforest.owo.ui.util.UISounds;
import io.wispforest.owo.util.NumberReflection;
import io.wispforest.owo.util.ReflectionUtils;
import org.apache.commons.lang3.mutable.MutableBoolean;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.glfw.GLFW;

import java.lang.reflect.Field;
import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.function.Predicate;
import net.minecraft.class_1074;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_437;
import net.minecraft.class_5250;
import net.minecraft.class_5481;
import net.minecraft.class_5684;

/**
 * A screen which generates components for each option in the
 * provided config. The general structure of the screen is determined
 * by the XML config model it uses - the default one is located at
 * {@code assets/owo/owo_ui/config.xml}. Changing which model is used
 * via {@link #createWithCustomModel(class_2960, ConfigWrapper, class_437)}
 * can often be enough to visually customize the generated screen - should
 * you need custom functionality however, extending this class is usually
 * your best bet
 *
 * @see io.wispforest.owo.config.annotation.Modmenu
 * @see ConfigWrapper
 */
public class ConfigScreen extends BaseUIModelScreen<FlowLayout> {

    public static final class_2960 DEFAULT_MODEL_ID = class_2960.method_60655("owo", "config");

    private static final Map<Predicate<Option<?>>, OptionComponentFactory<?>> DEFAULT_FACTORIES = new HashMap<>();
    /**
     * A set of extra option factories - add to this if you want to override
     * some default factories or add extra ones for specific config options
     * the standard ones don't support
     */
    protected final Map<Predicate<Option<?>>, OptionComponentFactory<?>> extraFactories = new HashMap<>();

    protected final class_437 parent;
    protected final ConfigWrapper<?> config;
    @SuppressWarnings("rawtypes") protected final Map<Option, OptionValueProvider> options = new HashMap<>();

    protected String lastSearchFieldText = "";
    protected @Nullable SearchMatches currentMatches = null;
    protected int currentMatchIndex = 0;

    protected ConfigScreen(class_2960 modelId, ConfigWrapper<?> config, @Nullable class_437 parent) {
        super(FlowLayout.class, DataSource.asset(modelId));
        this.parent = parent;
        this.config = config;
    }

    /**
     * Create a config screen with the default model ({@code owo:config})
     *
     * @param config The config to create a screen for
     * @param parent The parent screen to return to
     *               when the created screen is closed
     */
    public static ConfigScreen create(ConfigWrapper<?> config, @Nullable class_437 parent) {
        return new ConfigScreen(DEFAULT_MODEL_ID, config, parent);
    }

    /**
     * Create a config screen with a custom model
     * located in your mod's assets
     *
     * @param modelId The ID of the model to use
     * @param config  The config to create a screen for
     * @param parent  The parent screen to return to
     *                when the created screen is closed
     */
    public static ConfigScreen createWithCustomModel(class_2960 modelId, ConfigWrapper<?> config, @Nullable class_437 parent) {
        return new ConfigScreen(modelId, config, parent);
    }

    /**
     * @deprecated Use {@link ConfigScreenProviders#register(String, Function)} instead
     */
    @Deprecated(forRemoval = true)
    public static <S extends ConfigScreen> void registerProvider(String modId, Function<class_437, S> supplier) {
        ConfigScreenProviders.registerOwoConfigScreen(modId, supplier);
    }

    /**
     * @deprecated Use {@link ConfigScreenProviders#get(String)} instead
     */
    @Deprecated(forRemoval = true)
    public static @Nullable Function<class_437, ? extends ConfigScreen> getProvider(String modId) {
        return ConfigScreenProviders.getOwoProvider(modId);
    }

    /**
     * @deprecated Use {@link ConfigScreenProviders#forEach(BiConsumer)} instead
     */
    @Deprecated(forRemoval = true)
    public static void forEachProvider(BiConsumer<String, Function<class_437, ? extends ConfigScreen>> action) {
        ConfigScreenProviders.forEachOwoProvider(action);
    }

    @Override
    @SuppressWarnings({"ConstantConditions", "unchecked"})
    protected void build(FlowLayout rootComponent) {
        this.options.clear();

        rootComponent.childById(LabelComponent.class, "title").text(class_2561.method_43471("text.config." + this.config.name() + ".title"));
        if (this.field_22787.field_1687 == null) {
            rootComponent.surface(Surface.OPTIONS_BACKGROUND);
        }

        rootComponent.childById(ButtonComponent.class, "done-button").onPress(button -> this.method_25419());
        rootComponent.childById(ButtonComponent.class, "reload-button").onPress(button -> {
            this.config.load();
            this.uiAdapter = null;
            this.method_41843();

            // TODO check if any options changed and warn
        });

        var optionPanel = rootComponent.childById(FlowLayout.class, "option-panel");
        var sections = new LinkedHashMap<Component, class_2561>();

        var containers = new HashMap<Option.Key, FlowLayout>();
        containers.put(Option.Key.ROOT, optionPanel);

        rootComponent.childById(TextBoxComponent.class, "search-field").<TextBoxComponent>configure(searchField -> {
            var matchIndicator = rootComponent.childById(LabelComponent.class, "search-match-indicator");
            var optionScroll = rootComponent.childById(ScrollContainer.class, "option-panel-scroll");

            var searchHint = class_1074.method_4662("text.owo.config.search");
            searchField.method_1887(searchHint);
            searchField.onChanged().subscribe(s -> {
                searchField.method_1887(s.isEmpty() ? searchHint : "");
                if (!s.equals(this.lastSearchFieldText)) {
                    searchField.method_1868(TextBoxComponent.field_32196);
                    matchIndicator.text(class_2561.method_43473());
                }
            });

            searchField.keyPress().subscribe((keyCode, scanCode, modifiers) -> {
                if (keyCode != GLFW.GLFW_KEY_ENTER && keyCode != GLFW.GLFW_KEY_KP_ENTER) return false;

                var query = searchField.method_1882().toLowerCase(Locale.ROOT);
                if (query.isBlank()) return false;

                if (this.currentMatches != null && this.currentMatches.query.equals(query)) {
                    if (this.currentMatches.matches().isEmpty()) {
                        this.currentMatchIndex = -1;
                    } else {
                        this.currentMatchIndex = (this.currentMatchIndex + 1) % this.currentMatches.matches.size();
                    }
                } else {
                    var splitQuery = query.split(" ");

                    this.currentMatchIndex = 0;
                    this.currentMatches = new SearchMatches(query, this.collectSearchAnchors(optionScroll)
                            .stream()
                            .filter(anchor -> Arrays.stream(splitQuery).allMatch(anchor.currentSearchText()::contains))
                            .toList());
                }

                if (this.currentMatches.matches.isEmpty()) {
                    matchIndicator.text(class_2561.method_43471("text.owo.config.search.no_matches"));
                    searchField.method_1868(0xEB1D36);
                } else {
                    matchIndicator.text(class_2561.method_43469("text.owo.config.search.matches", this.currentMatchIndex + 1, this.currentMatches.matches.size()));
                    searchField.method_1868(0x28FFBF);

                    var selectedMatch = this.currentMatches.matches.get(this.currentMatchIndex);
                    var anchorFrame = selectedMatch.anchorFrame();

                    // we specifically build the path backwards, so we can then iterate
                    // it root -> key, otherwise we could potentially be manipulating
                    // unmounted components which is absolutely not desirable
                    var pathToRoot = new ArrayDeque<Option.Key>();
                    var key = selectedMatch.key();
                    while (!key.isRoot()) {
                        pathToRoot.push(key);
                        key = key.parent();
                    }

                    while (!pathToRoot.isEmpty()) {
                        if (containers.get(pathToRoot.pop()) instanceof CollapsibleContainer collapsible && !collapsible.expanded()) {
                            collapsible.toggleExpansion();
                        }
                    }

                    // in the same vein, the component is mounted after the layout is fully
                    // restored, as we would otherwise be mounting onto a partially-built subtree
                    if (anchorFrame instanceof FlowLayout flow) {
                        flow.child(0, selectedMatch.configure(new SearchHighlighterComponent()));
                    }

                    if (anchorFrame.y() < optionScroll.y() || anchorFrame.y() + anchorFrame.height() > optionScroll.y() + optionScroll.height()) {
                        optionScroll.scrollTo(selectedMatch.anchorFrame());
                    }
                }

                return true;
            });
        });

        this.config.forEachOption(option -> {
            if (option.backingField().hasAnnotation(ExcludeFromScreen.class)) return;

            var parentKey = option.key().parent();
            if (!parentKey.isRoot() && this.config.fieldForKey(parentKey).isAnnotationPresent(ExcludeFromScreen.class)) return;

            var factory = this.factoryForOption(option);
            if (factory == null) {
                Owo.LOGGER.warn("Could not create UI component for config option {}", option);
                return;
            }

            var result = factory.make(this.model, option);
            this.options.put(option, result.optionProvider());

            var expanded = !parentKey.isRoot() && this.config.fieldForKey(parentKey).isAnnotationPresent(Expanded.class);
            var container = containers.getOrDefault(
                    parentKey,
                    Containers.collapsible(
                            Sizing.fill(100), Sizing.content(),
                            class_2561.method_43471("text.config." + this.config.name() + ".category." + parentKey.asString()),
                            expanded
                    ).<CollapsibleContainer>configure(nestedContainer -> {
                        final var categoryKey = "text.config." + this.config.name() + ".category." + parentKey.asString();
                        if (class_1074.method_4663(categoryKey + ".tooltip")) {
                            nestedContainer.titleLayout().tooltip(class_2561.method_43471(categoryKey + ".tooltip"));
                        }

                        nestedContainer.titleLayout().child(new SearchAnchorComponent(
                                nestedContainer.titleLayout(),
                                option.key(),
                                () -> class_1074.method_4662(categoryKey)
                        ).highlightConfigurator(highlight ->
                                highlight.positioning(Positioning.absolute(-5, -5))
                                        .verticalSizing(Sizing.fixed(19))
                        ));
                    })
            );

            if (!containers.containsKey(parentKey) && containers.containsKey(parentKey.parent())) {
                if (this.config.fieldForKey(parentKey).isAnnotationPresent(SectionHeader.class)) {
                    this.appendSection(sections, this.config.fieldForKey(parentKey), containers.get(parentKey.parent()));
                }

                containers.put(parentKey, container);
                containers.get(parentKey.parent()).child(container);
            }

            if (option.detached()) {
                result.baseComponent().tooltip(
                        this.field_22787.field_1772.method_1728(class_2561.method_43471("text.owo.config.managed_by_server"), Integer.MAX_VALUE)
                                .stream().map(class_5684::method_32662).toList()
                );
            } else {
                var tooltipText = new ArrayList<class_5481>();
                var tooltipTranslationKey = option.translationKey() + ".tooltip";

                if (class_1074.method_4663(tooltipTranslationKey)) {
                    tooltipText.addAll(this.field_22787.field_1772.method_1728(class_2561.method_43471(tooltipTranslationKey), Integer.MAX_VALUE));
                }

                if (option.backingField().hasAnnotation(RestartRequired.class)) {
                    tooltipText.add(class_2561.method_43471("text.owo.config.applies_after_restart").method_30937());
                }

                if (!tooltipText.isEmpty()) {
                    result.baseComponent().tooltip(tooltipText.stream().map(class_5684::method_32662).toList());
                }
            }

            if (option.backingField().hasAnnotation(SectionHeader.class)) {
                this.appendSection(sections, option.backingField().field(), container);
            }

            container.child(result.baseComponent());
        });

        if (!sections.isEmpty()) {
            var panelContainer = rootComponent.childById(FlowLayout.class, "option-panel-container");
            var panelScroll = rootComponent.childById(ScrollContainer.class, "option-panel-scroll");
            panelScroll.margins(Insets.right(10));

            var buttonPanel = this.model.expandTemplate(FlowLayout.class, "section-buttons", Map.of());
            sections.forEach((component, text) -> {
                var hoveredText = text.method_27661().method_27692(class_124.field_1054);

                final var label = Components.label(text);
                label.cursorStyle(CursorStyle.HAND).margins(Insets.of(2));

                label.mouseEnter().subscribe(() -> label.text(hoveredText));
                label.mouseLeave().subscribe(() -> label.text(text));

                label.mouseDown().subscribe((mouseX, mouseY, button) -> {
                    panelScroll.scrollTo(component);
                    UISounds.playInteractionSound();
                    return true;
                });

                buttonPanel.child(label);
            });

            var closeButton = Components.label(class_2561.method_43470("<").method_27692(class_124.field_1067));
            closeButton.tooltip(class_2561.method_43471("text.owo.config.sections_tooltip"));
            closeButton.positioning(Positioning.relative(100, 50)).cursorStyle(CursorStyle.HAND).margins(Insets.right(2));

            panelContainer.child(closeButton);
            panelContainer.mouseDown().subscribe((mouseX, mouseY, button) -> {
                if (mouseX < panelContainer.width() - 10) return false;

                if (buttonPanel.horizontalSizing().animation() == null) {
                    buttonPanel.horizontalSizing().animate(350, Easing.CUBIC, Sizing.content());
                }

                buttonPanel.horizontalSizing().animation().reverse();
                closeButton.text(class_2561.method_43470(closeButton.text().getString().equals(">") ? "<" : ">").method_27692(class_124.field_1067));

                UISounds.playInteractionSound();
                return true;
            });

            rootComponent.childById(FlowLayout.class, "main-panel").child(buttonPanel);
        }
    }

    protected void appendSection(Map<Component, class_2561> sections, Field field, FlowLayout container) {
        var translationKey = "text.config." + this.config.name() + ".section."
                + field.getAnnotation(SectionHeader.class).value();

        final var header = this.model.expandTemplate(FlowLayout.class, "section-header", Map.of());
        header.childById(LabelComponent.class, "header").<LabelComponent>configure(label -> {
            label.text(class_2561.method_43471(translationKey).method_27695(class_124.field_1054, class_124.field_1067));
            header.child(new SearchAnchorComponent(header, Option.Key.ROOT, () -> label.text().getString()));
        });

        sections.put(header, class_2561.method_43471(translationKey));

        container.child(header);
    }

    protected List<SearchAnchorComponent> collectSearchAnchors(ParentComponent root) {
        var discovered = new ArrayList<SearchAnchorComponent>();
        var candidates = new ArrayDeque<>(root.children());

        while (!candidates.isEmpty()) {
            var candidate = candidates.poll();
            if (candidate instanceof CollapsibleContainer collapsible) {
                candidates.addAll(collapsible.children());
                if (!collapsible.expanded()) candidates.addAll(collapsible.collapsibleChildren());
            } else if (candidate instanceof ParentComponent parentComponent) {
                candidates.addAll(parentComponent.children());
            } else if (candidate instanceof SearchAnchorComponent anchor) {
                discovered.add(anchor);
            }
        }

        return discovered;
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_F && ((modifiers & GLFW.GLFW_MOD_CONTROL) != 0)) {
            this.uiAdapter.rootComponent.focusHandler().focus(
                    this.uiAdapter.rootComponent.childById(Component.class, "search-field"),
                    Component.FocusSource.MOUSE_CLICK
            );
            return true;
        } else {
            return super.method_25404(keyCode, scanCode, modifiers);
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public void method_25419() {
        var shouldRestart = new MutableBoolean();
        this.options.forEach((option, component) -> {
            if (!option.backingField().hasAnnotation(RestartRequired.class)) return;
            if (Objects.equals(option.value(), component.parsedValue())) return;

            shouldRestart.setTrue();
        });

        this.field_22787.method_1507(shouldRestart.booleanValue() ? new RestartRequiredScreen(this.parent) : this.parent);
    }

    @Override
    @SuppressWarnings("unchecked")
    public void method_25432() {
        this.options.forEach((option, component) -> {
            if (!component.isValid()) return;
            option.set(component.parsedValue());
        });
        super.method_25432();
    }

    @SuppressWarnings("rawtypes")
    protected @Nullable OptionComponentFactory factoryForOption(Option<?> option) {
        for (var predicate : this.extraFactories.keySet()) {
            if (!predicate.test(option)) continue;
            return this.extraFactories.get(predicate);
        }

        for (var predicate : DEFAULT_FACTORIES.keySet()) {
            if (!predicate.test(option)) continue;
            return DEFAULT_FACTORIES.get(predicate);
        }

        return null;
    }

    static {
        DEFAULT_FACTORIES.put(option -> NumberReflection.isNumberType(option.clazz()), OptionComponentFactory.NUMBER);
        DEFAULT_FACTORIES.put(option -> option.clazz() == String.class, OptionComponentFactory.STRING);
        DEFAULT_FACTORIES.put(option -> option.clazz() == Boolean.class || option.clazz() == boolean.class, OptionComponentFactory.BOOLEAN);
        DEFAULT_FACTORIES.put(option -> option.clazz() == class_2960.class, OptionComponentFactory.IDENTIFIER);
        DEFAULT_FACTORIES.put(option -> option.clazz() == Color.class, OptionComponentFactory.COLOR);
        DEFAULT_FACTORIES.put(option -> isStringOrNumberList(option.backingField().field()), OptionComponentFactory.LIST);
        DEFAULT_FACTORIES.put(option -> option.clazz().isEnum(), OptionComponentFactory.ENUM);

        UIParsing.registerFactory("config-slider", element -> new ConfigSlider());
        UIParsing.registerFactory("config-toggle-button", element -> new ConfigToggleButton());
        UIParsing.registerFactory("config-enum-button", element -> new ConfigEnumButton());
        UIParsing.registerFactory("config-text-box", element -> new ConfigTextBox());
    }

    protected record SearchMatches(String query, List<SearchAnchorComponent> matches) {}

    public static class SearchHighlighterComponent extends BaseComponent {

        private final Color startColor = Color.ofArgb(0x008d9be0);
        private final Color endColor = Color.ofArgb(0x4c8d9be0);

        private float age = 0;

        public SearchHighlighterComponent() {
            this.positioning(Positioning.absolute(0, 0));
            this.sizing(Sizing.fill(100), Sizing.fill(100));
        }

        @Override
        public void draw(OwoUIDrawContext context, int mouseX, int mouseY, float partialTicks, float delta) {
            final var mainColor = startColor.interpolate(endColor, (float) Math.sin(age / 25 * Math.PI)).argb();

            int segmentWidth = (int) (this.width * .3f);
            int baseX = (int) ((this.x - segmentWidth) + (Easing.CUBIC.apply(this.age / 25)) * (this.width + segmentWidth * 2));

            context.drawGradientRect(
                    baseX - segmentWidth, this.y,
                    segmentWidth, this.height,
                    0, mainColor,
                    mainColor, 0
            );
            context.drawGradientRect(
                    baseX, this.y,
                    segmentWidth, this.height,
                    mainColor, 0,
                    0, mainColor
            );
        }

        @Override
        public void update(float delta, int mouseX, int mouseY) {
            super.update(delta, mouseX, mouseY);
            if ((this.age += delta) > 25) {
                this.parent.queue(() -> this.parent.removeChild(this));
            }
        }
    }

    private static boolean isStringOrNumberList(Field field) {
        if (field.getType() != List.class) return false;

        var listType = ReflectionUtils.getTypeArgument(field.getGenericType(), 0);
        if (listType == null) return false;

        return String.class == listType || NumberReflection.isNumberType(listType);
    }
}
